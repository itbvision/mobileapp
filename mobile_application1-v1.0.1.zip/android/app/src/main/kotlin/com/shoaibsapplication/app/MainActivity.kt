package com.shoaibsapplication.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
