class ImageConstant {
  static String imgImage171x1713 = 'assets/images/img_image_171x171_3.png';

  static String imgRectangle7386x358 =
      'assets/images/img_rectangle7_386x358.png';

  static String img5279123tweettwittertwitter =
      'assets/images/img_5279123tweettwittertwitter.svg';

  static String imgPlus24x24 = 'assets/images/img_plus_24x24.svg';

  static String imgImage236x1713 = 'assets/images/img_image_236x171_3.png';

  static String imgSplash = 'assets/images/img_splash.png';

  static String imgRectangle7 = 'assets/images/img_rectangle7.png';

  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String imgArrowdown = 'assets/images/img_arrowdown.svg';

  static String imgClose = 'assets/images/img_close.svg';

  static String imgArrowleftGray90001 =
      'assets/images/img_arrowleft_gray_900_01.svg';

  static String imgImage171x1716 = 'assets/images/img_image_171x171_6.png';

  static String imgImage56x561 = 'assets/images/img_image_56x56_1.png';

  static String imgImage171x1715 = 'assets/images/img_image_171x171_5.png';

  static String imgImage1958x80 = 'assets/images/img_image19_58x80.png';

  static String imgFacebook = 'assets/images/img_facebook.svg';

  static String imgUnion = 'assets/images/img_union.svg';

  static String img25326b4294154be2a5c5f0d7c083e855 =
      'assets/images/img_25326b4294154be2a5c5f0d7c083e855.svg';

  static String imgImage56x562 = 'assets/images/img_image_56x56_2.png';

  static String imgImage236x1714 = 'assets/images/img_image_236x171_4.png';

  static String imgArrowright = 'assets/images/img_arrowright.svg';

  static String imgImage236x1711 = 'assets/images/img_image_236x171_1.png';

  static String imgUser = 'assets/images/img_user.svg';

  static String imgProfileimage100x100 =
      'assets/images/img_profileimage_100x100.png';

  static String imgImage61 = 'assets/images/img_image61.png';

  static String imgImage12 = 'assets/images/img_image_12.png';

  static String imgImage18 = 'assets/images/img_image18.png';

  static String imgSearchGray90001 = 'assets/images/img_search_gray_900_01.svg';

  static String imgRectangle1381354x292 =
      'assets/images/img_rectangle1381_354x292.png';

  static String imgMenuBlack900 = 'assets/images/img_menu_black_900.svg';

  static String imgSettings = 'assets/images/img_settings.svg';

  static String imgC57ba486ba4c404b89f72e3001eb7290 =
      'assets/images/img_c57ba486ba4c404b89f72e3001eb7290.svg';

  static String imgImage236x1712 = 'assets/images/img_image_236x171_2.png';

  static String imgEye26x26 = 'assets/images/img_eye_26x26.svg';

  static String imgImage236x1716 = 'assets/images/img_image_236x171_6.png';

  static String imgImage171x1714 = 'assets/images/img_image_171x171_4.png';

  static String imgRectangle11 = 'assets/images/img_rectangle11.png';

  static String imgImage15 = 'assets/images/img_image15.png';

  static String imgImage20 = 'assets/images/img_image20.png';

  static String imgPlus = 'assets/images/img_plus.svg';

  static String imgSearch = 'assets/images/img_search.svg';

  static String imgImage171x1712 = 'assets/images/img_image_171x171_2.png';

  static String imgImage17 = 'assets/images/img_image17.png';

  static String imgImage56x563 = 'assets/images/img_image_56x56_3.png';

  static String imgEdit = 'assets/images/img_edit.svg';

  static String imgImage110x109 = 'assets/images/img_image_110x109.png';

  static String imgImage60123x390 = 'assets/images/img_image60_123x390.png';

  static String imgGoogle = 'assets/images/img_google.svg';

  static String imgImage171x1711 = 'assets/images/img_image_171x171_1.png';

  static String imgCart = 'assets/images/img_cart.svg';

  static String imgRectangle8 = 'assets/images/img_rectangle8.png';

  static String imgImage236x1715 = 'assets/images/img_image_236x171_5.png';

  static String imgImage14204x231 = 'assets/images/img_image14_204x231.png';

  static String imgRectangle1385 = 'assets/images/img_rectangle1385.png';

  static String imgImage16 = 'assets/images/img_image16.png';

  static String imgEye = 'assets/images/img_eye.svg';

  static String imgTrash = 'assets/images/img_trash.svg';

  static String imgFacebook26x26 = 'assets/images/img_facebook_26x26.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
