import '../product_discover_screen/widgets/list_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:shoaib_s_application1/core/app_export.dart';
import 'package:shoaib_s_application1/widgets/app_bar/appbar_image.dart';
import 'package:shoaib_s_application1/widgets/app_bar/appbar_title.dart';
import 'package:shoaib_s_application1/widgets/app_bar/custom_app_bar.dart';

class ProductDiscoverScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            appBar: CustomAppBar(
                height: getVerticalSize(56),
                leadingWidth: 40,
                leading: AppbarImage(
                    height: getSize(24),
                    width: getSize(24),
                    svgPath: ImageConstant.img25326b4294154be2a5c5f0d7c083e855,
                    margin: getMargin(left: 16, top: 15, bottom: 16),
                    onTap: () {
                      onTapArrowleft(context);
                    }),
                centerTitle: true,
                title: AppbarTitle(text: "Shopsie")),
            body: Padding(
                padding: getPadding(left: 16, top: 5, right: 16),
                child: GridView.builder(
                    shrinkWrap: true,
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        mainAxisExtent: getVerticalSize(309),
                        crossAxisCount: 2,
                        mainAxisSpacing: getHorizontalSize(16),
                        crossAxisSpacing: getHorizontalSize(16)),
                    physics: NeverScrollableScrollPhysics(),
                    itemCount: 4,
                    itemBuilder: (context, index) {
                      return ListItemWidget();
                    }))));
  }

  onTapArrowleft(BuildContext context) {
    Navigator.pop(context);
  }
}
