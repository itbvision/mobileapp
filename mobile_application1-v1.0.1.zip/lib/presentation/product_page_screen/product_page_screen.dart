import '../product_page_screen/widgets/sliderrectangleeleven_item_widget.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:shoaib_s_application1/core/app_export.dart';
import 'package:shoaib_s_application1/widgets/app_bar/appbar_image.dart';
import 'package:shoaib_s_application1/widgets/app_bar/appbar_title.dart';
import 'package:shoaib_s_application1/widgets/app_bar/custom_app_bar.dart';
import 'package:shoaib_s_application1/widgets/custom_button.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

// ignore_for_file: must_be_immutable
class ProductPageScreen extends StatelessWidget {
  int silderIndex = 1;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            appBar: CustomAppBar(
                height: getVerticalSize(56),
                leadingWidth: 40,
                leading: AppbarImage(
                    height: getVerticalSize(22),
                    width: getHorizontalSize(24),
                    svgPath: ImageConstant.imgArrowleftGray90001,
                    margin: getMargin(left: 16, top: 12, bottom: 21),
                    onTap: () {
                      onTapArrowleft2(context);
                    }),
                centerTitle: true,
                title: AppbarTitle(text: "Shopsie")),
            body: Container(
                width: double.maxFinite,
                padding: getPadding(top: 6, bottom: 6),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      CarouselSlider.builder(
                          options: CarouselOptions(
                              height: getVerticalSize(289),
                              initialPage: 0,
                              autoPlay: true,
                              viewportFraction: 1.0,
                              enableInfiniteScroll: false,
                              scrollDirection: Axis.horizontal,
                              onPageChanged: (index, reason) {
                                silderIndex = index;
                              }),
                          itemCount: 1,
                          itemBuilder: (context, index, realIndex) {
                            return SliderrectangleelevenItemWidget();
                          }),
                      Align(
                          alignment: Alignment.center,
                          child: Container(
                              height: getVerticalSize(4),
                              margin: getMargin(top: 21),
                              child: AnimatedSmoothIndicator(
                                  activeIndex: silderIndex,
                                  count: 1,
                                  axisDirection: Axis.horizontal,
                                  effect: ScrollingDotsEffect(
                                      spacing: 4,
                                      activeDotColor: ColorConstant.indigoA200,
                                      dotColor: ColorConstant.gray600,
                                      dotHeight: getVerticalSize(4),
                                      dotWidth: getHorizontalSize(15))))),
                      Padding(
                          padding: getPadding(left: 20, top: 24),
                          child: Text("Print Maxi Dress",
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtLatoRegular24.copyWith(
                                  letterSpacing: getHorizontalSize(0.72)))),
                      Padding(
                          padding: getPadding(left: 20, top: 15),
                          child: Text("99.30",
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtLatoMedium20)),
                      Padding(
                          padding: getPadding(left: 20, top: 28),
                          child: Text("PRODUCT DETAILS".toUpperCase(),
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtLatoSemiBold14Gray90001)),
                      Align(
                          alignment: Alignment.center,
                          child: Container(
                              width: getHorizontalSize(356),
                              margin: getMargin(
                                  left: 20, top: 17, right: 13, bottom: 5),
                              child: Text(
                                  "Mini dress with gather at the sides. Button fastening and slightly dropped shoulder line. Wide sleeves with gathered cuffs. Vertical panels and gather in combination with voluminous sleeves visually adjust the silhouette, making it more graceful",
                                  maxLines: null,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtLatoRegular14Gray700)))
                    ])),
            bottomNavigationBar: CustomButton(
                height: getVerticalSize(48),
                text: "ADD TO CART".toUpperCase(),
                margin: getMargin(left: 16, right: 16, bottom: 64))));
  }

  onTapArrowleft2(BuildContext context) {
    Navigator.pop(context);
  }
}
