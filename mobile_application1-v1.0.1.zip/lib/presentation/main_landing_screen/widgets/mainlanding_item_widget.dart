import 'package:flutter/material.dart';
import 'package:shoaib_s_application1/core/app_export.dart';

// ignore: must_be_immutable
class MainlandingItemWidget extends StatelessWidget {
  MainlandingItemWidget();

  @override
  Widget build(BuildContext context) {
    return CustomImageView(
      imagePath: ImageConstant.imgImage15,
      height: getVerticalSize(
        58,
      ),
      width: getHorizontalSize(
        80,
      ),
    );
  }
}
