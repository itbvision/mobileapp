import 'package:flutter/material.dart';
import 'package:shoaib_s_application1/core/app_export.dart';

// ignore: must_be_immutable
class ListitemnameItemWidget extends StatelessWidget {
  ListitemnameItemWidget();

  @override
  Widget build(BuildContext context) {
    return IntrinsicWidth(
      child: Align(
        alignment: Alignment.centerRight,
        child: Padding(
          padding: getPadding(
            right: 10,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              CustomImageView(
                imagePath: ImageConstant.imgImage236x1712,
                height: getVerticalSize(
                  236,
                ),
                width: getHorizontalSize(
                  171,
                ),
                radius: BorderRadius.circular(
                  getHorizontalSize(
                    8,
                  ),
                ),
              ),
              Padding(
                padding: getPadding(
                  top: 11,
                ),
                child: Text(
                  "Olive plain dress",
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.left,
                  style: AppStyle.txtLatoRegular13.copyWith(
                    letterSpacing: getHorizontalSize(
                      0.39,
                    ),
                  ),
                ),
              ),
              Padding(
                padding: getPadding(
                  top: 9,
                ),
                child: Text(
                  " 20.99".toUpperCase(),
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.left,
                  style: AppStyle.txtLatoSemiBold13,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
