import 'package:flutter/material.dart';
import 'package:shoaib_s_application1/core/app_export.dart';
import 'package:shoaib_s_application1/widgets/custom_button.dart';
import 'package:shoaib_s_application1/widgets/custom_text_form_field.dart';

class RegisterScreen extends StatelessWidget {
  TextEditingController firstnameController = TextEditingController();

  TextEditingController lastnameController = TextEditingController();

  TextEditingController emailController = TextEditingController();

  TextEditingController passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorConstant.whiteA700,
        resizeToAvoidBottomInset: false,
        body: Container(
          width: double.maxFinite,
          padding: getPadding(
            left: 15,
            top: 98,
            right: 15,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text(
                "Hello! Register to get started",
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.left,
                style: AppStyle.txtLatoBold24.copyWith(
                  letterSpacing: getHorizontalSize(
                    0.72,
                  ),
                ),
              ),
              CustomTextFormField(
                focusNode: FocusNode(),
                controller: firstnameController,
                hintText: "First Name",
                margin: getMargin(
                  left: 1,
                  top: 40,
                ),
              ),
              CustomTextFormField(
                focusNode: FocusNode(),
                controller: lastnameController,
                hintText: "Last Name",
                margin: getMargin(
                  left: 1,
                  top: 12,
                ),
              ),
              CustomTextFormField(
                focusNode: FocusNode(),
                controller: emailController,
                hintText: "Email",
                margin: getMargin(
                  left: 1,
                  top: 12,
                ),
                textInputType: TextInputType.emailAddress,
              ),
              CustomTextFormField(
                focusNode: FocusNode(),
                controller: passwordController,
                hintText: "Password",
                margin: getMargin(
                  left: 1,
                  top: 12,
                ),
                textInputAction: TextInputAction.done,
                textInputType: TextInputType.visiblePassword,
                isObscureText: true,
              ),
              CustomButton(
                height: getVerticalSize(
                  48,
                ),
                text: "Register",
                margin: getMargin(
                  left: 1,
                  top: 24,
                ),
                fontStyle: ButtonFontStyle.LatoMedium16WhiteA700,
              ),
              Padding(
                padding: getPadding(
                  left: 1,
                  top: 38,
                  right: 1,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: getPadding(
                        top: 7,
                        bottom: 8,
                      ),
                      child: SizedBox(
                        width: getHorizontalSize(
                          112,
                        ),
                        child: Divider(
                          height: getVerticalSize(
                            1,
                          ),
                          thickness: getVerticalSize(
                            1,
                          ),
                          color: ColorConstant.indigo50,
                        ),
                      ),
                    ),
                    Text(
                      "Or Login with",
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: AppStyle.txtLatoRegular14Gray60001,
                    ),
                    Padding(
                      padding: getPadding(
                        top: 7,
                        bottom: 8,
                      ),
                      child: SizedBox(
                        width: getHorizontalSize(
                          111,
                        ),
                        child: Divider(
                          height: getVerticalSize(
                            1,
                          ),
                          thickness: getVerticalSize(
                            1,
                          ),
                          color: ColorConstant.indigo50,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: getPadding(
                  left: 1,
                  top: 21,
                  right: 1,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Card(
                      clipBehavior: Clip.antiAlias,
                      elevation: 0,
                      margin: EdgeInsets.all(0),
                      color: ColorConstant.whiteA700,
                      shape: RoundedRectangleBorder(
                        side: BorderSide(
                          color: ColorConstant.gray200,
                          width: getHorizontalSize(
                            1,
                          ),
                        ),
                        borderRadius: BorderRadiusStyle.roundedBorder8,
                      ),
                      child: Container(
                        height: getVerticalSize(
                          56,
                        ),
                        width: getHorizontalSize(
                          168,
                        ),
                        padding: getPadding(
                          top: 15,
                          bottom: 15,
                        ),
                        decoration: AppDecoration.white.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder8,
                        ),
                        child: Stack(
                          children: [
                            CustomImageView(
                              svgPath: ImageConstant.imgFacebook,
                              height: getSize(
                                26,
                              ),
                              width: getSize(
                                26,
                              ),
                              alignment: Alignment.center,
                            ),
                          ],
                        ),
                      ),
                    ),
                    Card(
                      clipBehavior: Clip.antiAlias,
                      elevation: 0,
                      margin: EdgeInsets.all(0),
                      color: ColorConstant.whiteA700,
                      shape: RoundedRectangleBorder(
                        side: BorderSide(
                          color: ColorConstant.gray200,
                          width: getHorizontalSize(
                            1,
                          ),
                        ),
                        borderRadius: BorderRadiusStyle.roundedBorder8,
                      ),
                      child: Container(
                        height: getVerticalSize(
                          56,
                        ),
                        width: getHorizontalSize(
                          168,
                        ),
                        padding: getPadding(
                          top: 15,
                          bottom: 15,
                        ),
                        decoration: AppDecoration.white.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder8,
                        ),
                        child: Stack(
                          children: [
                            CustomImageView(
                              svgPath: ImageConstant.imgGoogle,
                              height: getSize(
                                26,
                              ),
                              width: getSize(
                                26,
                              ),
                              alignment: Alignment.center,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Align(
                alignment: Alignment.center,
                child: Padding(
                  padding: getPadding(
                    top: 43,
                    bottom: 5,
                  ),
                  child: RichText(
                    text: TextSpan(
                      children: [
                        TextSpan(
                          text: "Already have an account?",
                          style: TextStyle(
                            color: ColorConstant.gray90001,
                            fontSize: getFontSize(
                              14,
                            ),
                            fontFamily: 'Lato',
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                        TextSpan(
                          text: " ",
                          style: TextStyle(
                            color: ColorConstant.gray900,
                            fontSize: getFontSize(
                              14,
                            ),
                            fontFamily: 'Lato',
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                        TextSpan(
                          text: "Login Now",
                          style: TextStyle(
                            color: ColorConstant.indigoA200,
                            fontSize: getFontSize(
                              14,
                            ),
                            fontFamily: 'Montserrat',
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                    textAlign: TextAlign.left,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
