import '../profile_address_details_page/widgets/listhomeaddress_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:shoaib_s_application1/core/app_export.dart';
import 'package:shoaib_s_application1/widgets/custom_button.dart';
import 'package:shoaib_s_application1/widgets/custom_text_form_field.dart';

// ignore_for_file: must_be_immutable
class ProfileAddressDetailsPage extends StatefulWidget {
  @override
  _ProfileAddressDetailsPageState createState() =>
      _ProfileAddressDetailsPageState();
}

class _ProfileAddressDetailsPageState extends State<ProfileAddressDetailsPage>
    with AutomaticKeepAliveClientMixin<ProfileAddressDetailsPage> {
  TextEditingController group5627Controller = TextEditingController();

  TextEditingController group5627OneController = TextEditingController();

  TextEditingController group5627TwoController = TextEditingController();

  TextEditingController group5627ThreeController = TextEditingController();

  TextEditingController group5627FourController = TextEditingController();

  @override
  bool get wantKeepAlive => true;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        resizeToAvoidBottomInset: false,
        body: SizedBox(
          width: size.width,
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Padding(
                  padding: getPadding(
                    left: 16,
                    top: 36,
                    right: 16,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text(
                        "Address 1",
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.left,
                        style: AppStyle.txtLatoMedium13Gray90002,
                      ),
                      CustomTextFormField(
                        focusNode: FocusNode(),
                        controller: group5627Controller,
                        hintText: "Enter address",
                        margin: getMargin(
                          top: 7,
                        ),
                        padding: TextFormFieldPadding.PaddingT14,
                      ),
                      Padding(
                        padding: getPadding(
                          top: 24,
                        ),
                        child: Text(
                          "Address 2",
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtLatoMedium13Gray90002,
                        ),
                      ),
                      CustomTextFormField(
                        focusNode: FocusNode(),
                        controller: group5627OneController,
                        hintText: "Enter address",
                        margin: getMargin(
                          top: 7,
                        ),
                        padding: TextFormFieldPadding.PaddingT14,
                      ),
                      Padding(
                        padding: getPadding(
                          top: 25,
                        ),
                        child: Text(
                          "City",
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtLatoMedium13Gray90002,
                        ),
                      ),
                      CustomTextFormField(
                        focusNode: FocusNode(),
                        controller: group5627TwoController,
                        hintText: "Enter your city",
                        margin: getMargin(
                          top: 6,
                        ),
                        padding: TextFormFieldPadding.PaddingT14,
                      ),
                      Padding(
                        padding: getPadding(
                          top: 24,
                        ),
                        child: Text(
                          "Postal Code",
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtLatoMedium13Gray90002,
                        ),
                      ),
                      CustomTextFormField(
                        focusNode: FocusNode(),
                        controller: group5627ThreeController,
                        hintText: "Enter postal code",
                        margin: getMargin(
                          top: 7,
                        ),
                        padding: TextFormFieldPadding.PaddingT14,
                      ),
                      Padding(
                        padding: getPadding(
                          top: 24,
                        ),
                        child: Text(
                          "Phone number",
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtLatoMedium13Gray90002,
                        ),
                      ),
                      CustomTextFormField(
                        focusNode: FocusNode(),
                        controller: group5627FourController,
                        hintText: "Enter phone number",
                        margin: getMargin(
                          top: 7,
                        ),
                        padding: TextFormFieldPadding.PaddingT14,
                        textInputAction: TextInputAction.done,
                        textInputType: TextInputType.phone,
                      ),
                      CustomButton(
                        height: getVerticalSize(
                          48,
                        ),
                        text: "add another address".toUpperCase(),
                        margin: getMargin(
                          top: 24,
                        ),
                        variant: ButtonVariant.OutlineIndigoA200,
                        fontStyle: ButtonFontStyle.LatoSemiBold13IndigoA200,
                      ),
                      Padding(
                        padding: getPadding(
                          top: 24,
                        ),
                        child: Text(
                          "Current addresses".toUpperCase(),
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtLatoSemiBold13Gray90001,
                        ),
                      ),
                      Padding(
                        padding: getPadding(
                          top: 23,
                        ),
                        child: ListView.separated(
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          separatorBuilder: (context, index) {
                            return SizedBox(
                              height: getVerticalSize(
                                24,
                              ),
                            );
                          },
                          itemCount: 2,
                          itemBuilder: (context, index) {
                            return ListhomeaddressItemWidget();
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
